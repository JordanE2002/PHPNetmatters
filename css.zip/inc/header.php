<header>
        <div class="container header-background">
            <div class="header-row">
                <div class="header-logo-container">
                    <a href="#">
                        <img src="images/f-logo.webp" class="header-image" alt="Netmatters Logo">
                    </a>
                </div>
    
                <div class="header-actions-container">
                    <div class="header-btn-support-container">
                        <a href="#" class="header-support-button"><span class="icon-mouse1"></span> Support</a>
                    </div>
    
                    <div class="header-btn-contact-container">
                        <a href="contact.php" class="header-contact-button"><span class="icon-paperplane "></span> Contact</a>
                    </div>
    
                    <div class="header-phone-container">
                        <span class="icon-phone_in_talk"></span>
                    </div>
                    
                   

                    
                    <form class="header-large-form-container">
                        <input class="header-form-large" type="text" placeholder="Search...">
                        <button class="header-large-form-icon-container"><span class="icon-search-large icon-search"></span></button>
                        
                        
                    </form>
    
                    
            <div class="header-icon-menu-container" id="hamburger">
                <span class="header-hamburger-box">
                    <span class="header-hamburger-inner"></span>
                </span>
            </div>
            

            <div id="menu" class="right-menu hidden">
                
             

            
           

                    <div class ="box">Contact us</div>

                   

                  
                    <div class ="box">
                        <div class="nav-dropdown-item ddm-software">
                                <span class="icon-laptop-ddm icon-laptop"></span>
                                <small>Bespoke</small>
                                Software
                        </div>
                    </div>

                    <ul>
                    <li><a href="#">Bespoke CRM</a></li>
                    <li><a href="#"> Business Automation</a></li>
                     <li><a href="#">Software intergrations</a></li>
                     <li><a href="#">Mobile App Devopment </a></li>
                     <li><a href="#">Bespoke Databases</a></li>
                     <li><a href="#">Sharepoint Devopment</a></li>
                     <li><a href="#">Operational Systems</a></li>
                     <li><a href="#">Business Central Implementation</a></li>
                     <li><a href="#">Internet of Things (IoT) Software</a></li>
                     <li><a href="#">Intranet Devopment</a></li>
                     <li><a href="#">Customer Portal Devoloment</a></li>
                     <li><a href="#">Reporting Hub</a></li>
                     <li><a href="#">Sap S/4HANA Management</a></li>

                     </ul>


                     
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-it-support">
                                        <span class="icon-it-support-ddm icon-display"></span>
                                        <small>IT</small>
                                        Support
                                </div>
                            </div>
                            <ul>
                            <li><a href="#">Managed IT Support</a></li>
                            <li><a href="#"> Business IT Support</a></li>
                             <li><a href="#">Office 365 For Business</a></li>
                             <li><a href="#">IT Consultancy</a></li>
                             <li><a href="#">Clous Service Provider</a></li>
                             <li><a href="#">Data Backup and Disaster Recovery</a></li>
                         </ul>



                       
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-stats-bars">
                                        <span class="icon-it-support-ddm icon-stats-bars"></span>
                                        <small>Digital</small>
                                        Marketing
                                </div>
                            </div>
                            <ul>
                            <li><a href="#">Search Engine Optimisation (SEO)</a></li>
                            <li><a href="#"> Pay Per Click Advertising (PPC)</a></li>
                             <li><a href="#">Conversion Rate Optimisation (CRO)</a></li>
                             <li><a href="#">Email Marketing</a></li>
                             <li><a href="#">Content Marketing</a></li>
                         </ul>



                       
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-telecoms-service">
                                        <span class="icon-telecoms-service-ddm icon-phone_in_talk"></span>
                                        <small>Web</small>
                                        Design
                                </div>
                            </div>
                            <ul>
                            <li><a href="#">Business Mobile</a></li>
                            <li><a href="#"> Hosted VOIP Provider</a></li>
                             <li><a href="#">Business VOIP Systems</a></li>
                             <li><a href="#">Buisness Broadband</a></li>
                             <li><a href="#">Leased Lines Provider</a></li>
                             <li><a href="#">3CX Systems</a></li>
                         </ul>


                       
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-web-design">
                                        <span class="icon-web-design-ddm icon-embed"></span>
                                        <small>Cyber</small>
                                        Security
                                </div>
                            </div>
                            <ul>
                            <li><a href="#">Bespoke Website Design</a></li>
                            <li><a href="#">Ecommerce Website Design</a></li>
                             <li><a href="#">Pay Monthly Websites</a></li>
                             <li><a href="#">Branding & Design</a></li>
                             <li><a href="#">Mobile App Development</a></li>
                             <li><a href="#">Web Hosting</a></li>
                         </ul>

                        
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-cyber-security">
                                        <span class="icon-cyber-security-ddm icon-security"></span>
                                        <small>Cyber</small>
                                        Security
                                </div>
                            </div>
                            <ul>
                            <li><a href="#">Cyber Security Assessment</a></li>
                            <li><a href="#">Cyber Security Management</a></li>
                             <li><a href="#">Cyber Penetration Testing</a></li>
                             <li><a href="#">Cyber Essentials Certification</a></li>
                             <li><a href="#">PCI Compliance</a></li>
                             <li><a href="#">Hacking Prevention</a></li>
                         </ul>


            

                      
                            <div class ="box">
                                <div class="nav-dropdown-item ddm-hosted-solutions">
                                        <span class="icon-hosted-solutions-ddm icon-graduate"></span>
                                        <small>Cyber</small>
                                        Security
                                </div>
                            </div>
                               <ul>
                            <li><a href="#">Train For a Career in Tech</a></li>
                            <li><a href="#">Skills Bootcamp</a></li>
                             <li><a href="#">Scion Scheme Frequenly Asked Questions</a></li>
                             <li><a href="#">Scion Collaborators</a></li>
                         </ul>

        


                         <ol>
                            <li><a href="#">Services</a></li>
                        </ol>
                        
                     <ul>
                    
                        <li><a href="#"><span class="bb-arrow"></span> Bespoke Software</a></li>
                        <li><a href="#"><span class="bb-arrow"></span>IT Support</a></li>
                         <li><a href="#"><span class="bb-arrow"></span>Digital Marketing</a></li>
                         <li><a href="#"><span class="bb-arrow"></span>Telecoms Services</a></li>
                         <li><a href="#"><span class="bb-arrow"></span> Web Design</a></li>
                         <li><a href="#"><span class="bb-arrow"></span>Cyber Security</a></li>
    
                         </ul>


                         <ol>
                            <li><a href="#">Our Work</a></li>
                        </ol>
                     <ul>
            
                    <li><a href="#"><span class="bb-arrow"></span>Our Case Studies</a></li>   
                    <li><a href="#"><span class="bb-arrow"></span>Our Digital Marketing Clients</a></li>      
                    <li><a href="#"><span class="bb-arrow"></span>Our Website Clients</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>Our IT CAlients</a></li>
                    <li><a href="#"><span class="bb-arrow"></span>Our Bespoke Software Clients</a></li>
                    <li><a href="#"><span class="bb-arrow"></span>Our Telecoms clients</a></li>
                     </ul>
            
                     <ol>
                        <li><a href="#">Our Knowledge</a></li>
                    </ol>

                    <ul>
                    <li><a href="#"><span class="bb-arrow"></span>Technologies</a></li>      
                    <li><a href="#"><span class="bb-arrow"></span>Industries</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>News</a></li>
                    <li><a href="#"><span class="bb-arrow"></span>Insight</a></li>

                    </ul>

                    <ol>
                        <li><a href="#">Training</a></li>
                    </ol>

                    <ul>
                    <li><a href="#"><span class="bb-arrow"></span>Train For A Career In Tech </a></li>      
                    <li><a href="#"><span class="bb-arrow"></span>Skills Bootcamp</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>SCS Frequently Asked Questions</a></li>
                    <li><a href="#"><span class="bb-arrow"></span>Scion Collaborators</a></li>
            
                </ul>

                <ol>
                    <li><a href="#">Our Culture</a></li>
                </ol>
                <ul>
                    <li><a href="#"><span class="bb-arrow"></span>Why Choose us?</a></li> 
                    <li><a href="#"><span class="bb-arrow"></span>Our Culture</a></li>      
                    <li><a href="#"><span class="bb-arrow"></span>Our Team</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>Our Carers</a></li>
                    <li><a href="#"><span class="bb-arrow"></span>Our benefits</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>Our Accreditions</a></li>
                </ul>
                    

                <ol>
                    <li><a href="#">Contact Us</a></li>
                </ol>
                <ul>
                    <li><a href="#"><span class="bb-arrow"></span>Cambridge Office</a></li>      
                    <li><a href="#"><span class="bb-arrow"></span>Wymondham Office</a></li>  
                    <li><a href="#"><span class="bb-arrow"></span>Great Yarmouth office</a></li>
                   
                </ul>


                <ol>
                    <li><a href="#">Covid Risk Assessment</a></li>
                </ol>
              
            </div>
            
        </div>
        </div>
        <div class="header-form-container">
            <form class="header-form">
                <input type="text" class="header-form-small" placeholder="Search...">
                <button class="header-icon-search-small"><span class="icon-search"></span>
                </button>
            </form>
        </div>
        </div>


        

        

<!--Had trouble using the triangle and h3 placement-->

    <div class="nav-dropdown-menu-container">
        <div class="container">
            <div class="nav-dropdown-row">

                <div class="nav-main nav-dropdown-item-1">
                    <div  class="nav-dropdown-item ddm-software">
                        <span class="icon-laptop-ddm icon-laptop"></span>
                        <small>Bespoke</small>
                        Software

                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">
                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Bespoke Software Services</h3>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Bespoke CRM</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Business Automation</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Software Integrations</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Mobile App Development</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Bespoke Databases</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Sharepoint Development</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Operational Systems</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Business Central Implementation</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Internet of Things (IoT) Software</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Intranet Development</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Customer Portal Development</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">Reporting Hub</a></div>
                                <div class="sub-menu-item"><span class="icon-laptop"></span><a href="#" class="sub-menu-a-underline">SAP S/4HANA Management</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-2">
                    <div class="nav-dropdown-item ddm-it-support">
                        <span class="icon-it-support-ddm icon-display"></span>
                        <small>IT</small>
                        Support
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">
                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our IT Support Service</h3>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">Managed IT Support</a></div>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">Business IT Support</a></div>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">Office 365 for Business</a></div>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">IT Consultancy</a></div>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">Cloud Service Provider</a></div>
                                <div><span class="icon-display"></span><a href="#" class="sub-menu-a-underline">Data Backup & Disaster Recovery</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-3">
                    <div class="nav-dropdown-item ddm-stats-bars">
                        <span class="icon-stats-bars-ddm  icon-stats-bars"></span>
                        <small>Digital</small>
                        Marketing
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">
                          
                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Digital Marketing Services</h3>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Search Engine Optimisation (SEO)</a></div>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Pay Per Click Advertising (PPC)</a></div>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Conversion Rate Optimisation (CRO)</a></div>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Email Marketing</a></div>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Social Media Marketing</a></div>
                                <div><span class="icon-stats-bars"></span><a href="#" class="sub-menu-a-underline">Content Marketing</a></div>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-4">
                    <div class="nav-dropdown-item ddm-telecoms-service">
                        <span class="icon-telecoms-service-ddm icon-phone_in_talk"></span>
                        <small>Telecoms</small>
                        Services
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">
                           
                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Telecoms Services</h3>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">Business Mobile</a></div>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">Hosted VoIP Provider</a></div>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">Business VoIP Systems</a></div>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">Business Broadband</a></div>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">Leased Lines Provider</a></div>
                                <div ><span class="icon-phone_in_talk"></span><a href="#" class="sub-menu-a-underline">3CX Systems</a></div>
                            </div >
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-5">
                    <div class="nav-dropdown-item ddm-web-design">
                        <span class="icon-web-design-ddm icon-embed"></span>
                        <small>Web</small>
                        Design
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">

                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Web Design Services</h3>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">Bespoke Website Design</a></div>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">eCommerce Website Design</a></div>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">Pay Monthly Websites</a></div>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">Branding & Design</a></div>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">Mobile App Development</a></div>
                                <div><span class="icon-embed"></span><a href="#" class="sub-menu-a-underline">Web Hosting</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-6">
                    <div class="nav-dropdown-item ddm-cyber-security">
                        <span class="icon-cyber-security-ddm icon-security"></span>
                        <small>Cyber</small>
                        Security
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">
                          
                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Cyber Security Services</h3>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">Cyber Security Assessment</a></div>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">Cyber Security Management</a></div>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">Cyber Penetration Testing</a></div>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">Cyber Essentials Certification</a></div>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">PCI Compliance</a></div>
                                <div><span class="icon-security"></span><a href="#" class="sub-menu-a-underline">Hacking Prevention</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav-main nav-dropdown-item-7">
                    <div class="nav-dropdown-item ddm-hosted-solutions">
                        <span class="icon-hosted-solutions-ddm icon-graduate"></span>
                        <small>Developer</small>
                        Course
                        <span class="dropdown-triangle"></span>
                        <div class="sub-menu-container">

                            <div class="container sub-menu">
                                <h3 class="sub-menu-title">Our Developer Course Services</h3>
                                <div><span class="icon-graduate"></span><a href="#" class="sub-menu-a-underline">Train For A Career In Tech</a></div>
                                <div><span class="icon-graduate"></span><a href="#" class="sub-menu-a-underline">Skills Bootcamp</a></div>
                                <div><span class="icon-graduate"></span><a href="#" class="sub-menu-a-underline">Scion Scheme Frequently Asked Questions</a></div>
                                <div><span class="icon-graduate"></span><a href="#" class="sub-menu-a-underline">Scion Collaborators</a></div>
                            <div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    </div>
</header>
