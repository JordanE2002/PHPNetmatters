1. I know the fotter is not great, i really struggled with the footer i must admit 
Apart from the footer all the work look pretty identical to the origianal ges
I did not include Header and dropbox as i was trying to do all the items in the right orde and just did not get time to them in the end.